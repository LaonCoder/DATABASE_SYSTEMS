-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: video_database
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `watch`
--

DROP TABLE IF EXISTS `watch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `watch` (
  `email` varchar(100) NOT NULL,
  `video_id` char(64) NOT NULL,
  `last_viewed_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`,`video_id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `watch_ibfk_1` FOREIGN KEY (`email`) REFERENCES `users` (`email`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `watch_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `video` (`video_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `watch`
--

LOCK TABLES `watch` WRITE;
/*!40000 ALTER TABLE `watch` DISABLE KEYS */;
INSERT INTO `watch` VALUES ('user1@gmail.com','0srJwFoNSfkLXQDSZwjgbMm5rWNvCBwG','2022-12-10 07:11:24'),('user1@gmail.com','9isggOYC9KfbfVg26O6vnzLLRojjLMag','2022-12-10 07:12:55'),('user1@gmail.com','Avf1bDgai7qL9FJjUY5gNJw9nfi0vlHZ','2022-12-10 07:16:58'),('user1@gmail.com','awRpmasPDO9OMQicLzOG5WtEHdYjd9oS','2022-12-10 07:13:03'),('user1@gmail.com','Bbo9qekAE4oZe3JkizoNFuc6PpkGgNCb','2022-12-10 07:13:11'),('user1@gmail.com','hDl4vbcUDsRTYF2Wbmu6fteYV4X2tJk8','2022-12-10 07:13:28'),('user1@gmail.com','LG1DFaqLnisjIlTIcP7uzZuktsMfNnIT','2022-12-10 07:13:53'),('user1@gmail.com','Q4AAe6p0Rk0HkW4ZZtJJDdkwBZ55iOK4','2022-12-10 07:14:01'),('user2@gmail.com','0srJwFoNSfkLXQDSZwjgbMm5rWNvCBwG','2022-12-10 07:24:11'),('user2@gmail.com','9isggOYC9KfbfVg26O6vnzLLRojjLMag','2022-12-10 07:24:01'),('user2@gmail.com','hDl4vbcUDsRTYF2Wbmu6fteYV4X2tJk8','2022-12-10 07:24:16'),('user2@gmail.com','JQcQR4AqGqAHW0fPlRlqv8ba4bl1oqw9','2022-12-10 07:24:25'),('user2@gmail.com','lWAVtjvNig0VsIGL50cn9qM8C0Qz57Lf','2022-12-10 07:24:42'),('user2@gmail.com','nBT2OvJ9Hp8EnhIaPELrHQe25MRREWKu','2022-12-10 07:24:37'),('user2@gmail.com','sXHhC43n4TvH0ioRLrnunSUTgFDtqGpm','2022-12-10 07:24:47'),('user2@gmail.com','u2AbGw39r3r1MzpT8zD5nZdGFnUqyUfk','2022-12-10 07:24:53'),('user2@gmail.com','YjfFuxxlQFwFZohMRIYAhKlXMp9FX95R','2022-12-10 07:25:43'),('user3@gmail.com','0srJwFoNSfkLXQDSZwjgbMm5rWNvCBwG','2022-12-10 07:28:14'),('user3@gmail.com','9isggOYC9KfbfVg26O6vnzLLRojjLMag','2022-12-10 07:28:36'),('user3@gmail.com','A5OhsZKVMvkr07QIE2OTd2FrZQXm91lW','2022-12-10 07:28:42'),('user3@gmail.com','Avf1bDgai7qL9FJjUY5gNJw9nfi0vlHZ','2022-12-10 07:28:49'),('user3@gmail.com','C99TbUX8y6nSpOt0Blhqlik9kzQ0AWoU','2022-12-10 07:28:56'),('user3@gmail.com','GN1UvMAQp5jLg71mhPoOn1eCRDB3yLUo','2022-12-10 07:29:02'),('user3@gmail.com','Iltc83wQ1G3vZ1M9fOVyxQbuXGOYujfc','2022-12-10 07:29:13'),('user4@gmail.com','0srJwFoNSfkLXQDSZwjgbMm5rWNvCBwG','2022-12-10 07:32:58'),('user4@gmail.com','Avf1bDgai7qL9FJjUY5gNJw9nfi0vlHZ','2022-12-10 07:33:15'),('user4@gmail.com','C99TbUX8y6nSpOt0Blhqlik9kzQ0AWoU','2022-12-10 07:33:26'),('user4@gmail.com','CFAvmEiM39kuHdg0oaUJpBaLHCuHwDL5','2022-12-10 07:33:31'),('user4@gmail.com','E22dSDIyXcoF5yCyg4EY2mAuyBJYpqbk','2022-12-10 07:33:38'),('user4@gmail.com','Iltc83wQ1G3vZ1M9fOVyxQbuXGOYujfc','2022-12-10 07:35:22'),('user4@gmail.com','lWAVtjvNig0VsIGL50cn9qM8C0Qz57Lf','2022-12-10 07:35:33'),('user4@gmail.com','nBT2OvJ9Hp8EnhIaPELrHQe25MRREWKu','2022-12-10 07:35:28'),('user4@gmail.com','YjfFuxxlQFwFZohMRIYAhKlXMp9FX95R','2022-12-10 07:35:40'),('user5@gmail.com','0srJwFoNSfkLXQDSZwjgbMm5rWNvCBwG','2022-12-10 07:38:39'),('user5@gmail.com','awRpmasPDO9OMQicLzOG5WtEHdYjd9oS','2022-12-10 07:38:47'),('user5@gmail.com','Bbo9qekAE4oZe3JkizoNFuc6PpkGgNCb','2022-12-10 07:38:54'),('user5@gmail.com','GN1UvMAQp5jLg71mhPoOn1eCRDB3yLUo','2022-12-10 07:39:38'),('user5@gmail.com','hDl4vbcUDsRTYF2Wbmu6fteYV4X2tJk8','2022-12-10 07:39:48'),('user5@gmail.com','IQuqFi5xNn8Zc7gP5uVkcBxRabtmPrAI','2022-12-10 07:40:11'),('user5@gmail.com','LG1DFaqLnisjIlTIcP7uzZuktsMfNnIT','2022-12-10 07:40:28'),('user5@gmail.com','nmC9NYdlWCY0jWqqp9tzvbpXgkF5i6Jg','2022-12-10 07:40:35'),('user5@gmail.com','V9RX4R5i0Urc3NreZsdIzHtL8OTZcweT','2022-12-10 07:40:44'),('user5@gmail.com','YjfFuxxlQFwFZohMRIYAhKlXMp9FX95R','2022-12-10 07:41:00'),('user6@gmail.com','0srJwFoNSfkLXQDSZwjgbMm5rWNvCBwG','2022-12-10 07:43:13'),('user6@gmail.com','9isggOYC9KfbfVg26O6vnzLLRojjLMag','2022-12-10 07:43:25'),('user6@gmail.com','A5OhsZKVMvkr07QIE2OTd2FrZQXm91lW','2022-12-10 07:43:34'),('user6@gmail.com','awRpmasPDO9OMQicLzOG5WtEHdYjd9oS','2022-12-10 07:44:02'),('user6@gmail.com','E22dSDIyXcoF5yCyg4EY2mAuyBJYpqbk','2022-12-10 07:44:13'),('user6@gmail.com','GN1UvMAQp5jLg71mhPoOn1eCRDB3yLUo','2022-12-10 07:44:21'),('user6@gmail.com','haqIE7tK1O66CAKoKj0ZcfCfuRAqqofW','2022-12-10 07:44:27'),('user6@gmail.com','hDl4vbcUDsRTYF2Wbmu6fteYV4X2tJk8','2022-12-10 07:44:33'),('user6@gmail.com','Iltc83wQ1G3vZ1M9fOVyxQbuXGOYujfc','2022-12-10 07:44:42'),('user6@gmail.com','IQuqFi5xNn8Zc7gP5uVkcBxRabtmPrAI','2022-12-10 07:44:47'),('user6@gmail.com','jf8qzdZCZukQ2EU12wNaH4oYG4iCz8EI','2022-12-10 07:44:52'),('user6@gmail.com','jOlGyREOq55NJzYl2Xz6UNkgoyfvd4R3','2022-12-10 07:45:00'),('user6@gmail.com','JQcQR4AqGqAHW0fPlRlqv8ba4bl1oqw9','2022-12-10 07:45:06'),('user6@gmail.com','lWAVtjvNig0VsIGL50cn9qM8C0Qz57Lf','2022-12-10 07:45:17'),('user6@gmail.com','nBT2OvJ9Hp8EnhIaPELrHQe25MRREWKu','2022-12-10 07:45:11'),('user6@gmail.com','sXHhC43n4TvH0ioRLrnunSUTgFDtqGpm','2022-12-10 07:45:23'),('user6@gmail.com','u2AbGw39r3r1MzpT8zD5nZdGFnUqyUfk','2022-12-10 07:45:27'),('user7@gmail.com','0srJwFoNSfkLXQDSZwjgbMm5rWNvCBwG','2022-12-10 07:47:12'),('user7@gmail.com','9isggOYC9KfbfVg26O6vnzLLRojjLMag','2022-12-10 07:47:41'),('user7@gmail.com','Avf1bDgai7qL9FJjUY5gNJw9nfi0vlHZ','2022-12-10 07:47:54'),('user7@gmail.com','awRpmasPDO9OMQicLzOG5WtEHdYjd9oS','2022-12-10 07:47:58'),('user7@gmail.com','C99TbUX8y6nSpOt0Blhqlik9kzQ0AWoU','2022-12-10 07:48:09'),('user7@gmail.com','CFAvmEiM39kuHdg0oaUJpBaLHCuHwDL5','2022-12-10 07:48:04'),('user7@gmail.com','Iltc83wQ1G3vZ1M9fOVyxQbuXGOYujfc','2022-12-10 07:48:28'),('user7@gmail.com','J7UR63BwwH1LIN36LGbsjqKJwJx7WnyX','2022-12-10 07:48:34'),('user7@gmail.com','jf8qzdZCZukQ2EU12wNaH4oYG4iCz8EI','2022-12-10 07:48:38'),('user7@gmail.com','jOlGyREOq55NJzYl2Xz6UNkgoyfvd4R3','2022-12-10 07:48:46'),('user7@gmail.com','JQcQR4AqGqAHW0fPlRlqv8ba4bl1oqw9','2022-12-10 07:48:52'),('user7@gmail.com','JzPbbUOUCRKtMCYQ4dPsW6dWz6oo5OnV','2022-12-10 07:48:57'),('user7@gmail.com','lWAVtjvNig0VsIGL50cn9qM8C0Qz57Lf','2022-12-10 07:49:03'),('user7@gmail.com','nBT2OvJ9Hp8EnhIaPELrHQe25MRREWKu','2022-12-10 07:49:08'),('user7@gmail.com','nhy1AWUUceNFTvPfVCjEXNAd7lI02FPH','2022-12-10 07:49:14'),('user7@gmail.com','sVfRfl0ksXYAFFNqE5xA17ymNxSfzyg3','2022-12-10 07:49:20'),('user7@gmail.com','sXHhC43n4TvH0ioRLrnunSUTgFDtqGpm','2022-12-10 07:49:24'),('user7@gmail.com','u2AbGw39r3r1MzpT8zD5nZdGFnUqyUfk','2022-12-10 07:49:28'),('user7@gmail.com','YjfFuxxlQFwFZohMRIYAhKlXMp9FX95R','2022-12-10 07:49:35'),('user8@gmail.com','0srJwFoNSfkLXQDSZwjgbMm5rWNvCBwG','2022-12-10 07:52:07'),('user8@gmail.com','9isggOYC9KfbfVg26O6vnzLLRojjLMag','2022-12-10 07:51:57'),('user8@gmail.com','Avf1bDgai7qL9FJjUY5gNJw9nfi0vlHZ','2022-12-10 07:52:25'),('user8@gmail.com','awRpmasPDO9OMQicLzOG5WtEHdYjd9oS','2022-12-10 07:52:30'),('user8@gmail.com','CFAvmEiM39kuHdg0oaUJpBaLHCuHwDL5','2022-12-10 07:52:37'),('user8@gmail.com','E22dSDIyXcoF5yCyg4EY2mAuyBJYpqbk','2022-12-10 07:52:43'),('user8@gmail.com','haqIE7tK1O66CAKoKj0ZcfCfuRAqqofW','2022-12-10 07:58:08'),('user8@gmail.com','hDl4vbcUDsRTYF2Wbmu6fteYV4X2tJk8','2022-12-10 07:58:25'),('user8@gmail.com','Iltc83wQ1G3vZ1M9fOVyxQbuXGOYujfc','2022-12-10 07:53:01'),('user8@gmail.com','J7UR63BwwH1LIN36LGbsjqKJwJx7WnyX','2022-12-10 07:53:13'),('user8@gmail.com','jf8qzdZCZukQ2EU12wNaH4oYG4iCz8EI','2022-12-10 07:53:17'),('user8@gmail.com','JzPbbUOUCRKtMCYQ4dPsW6dWz6oo5OnV','2022-12-10 07:53:23'),('user8@gmail.com','nhy1AWUUceNFTvPfVCjEXNAd7lI02FPH','2022-12-10 07:53:36'),('user8@gmail.com','sVfRfl0ksXYAFFNqE5xA17ymNxSfzyg3','2022-12-10 07:58:13'),('user8@gmail.com','sXHhC43n4TvH0ioRLrnunSUTgFDtqGpm','2022-12-10 07:53:43'),('user8@gmail.com','u2AbGw39r3r1MzpT8zD5nZdGFnUqyUfk','2022-12-10 07:58:52'),('user8@gmail.com','YjfFuxxlQFwFZohMRIYAhKlXMp9FX95R','2022-12-10 07:53:55'),('user9@gmail.com','0srJwFoNSfkLXQDSZwjgbMm5rWNvCBwG','2022-12-10 07:56:52'),('user9@gmail.com','YjfFuxxlQFwFZohMRIYAhKlXMp9FX95R','2022-12-10 07:56:43');
/*!40000 ALTER TABLE `watch` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-10 22:41:45
