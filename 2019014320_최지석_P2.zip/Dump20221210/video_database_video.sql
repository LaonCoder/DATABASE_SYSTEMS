-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: video_database
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video` (
  `video_id` char(64) NOT NULL,
  `title` varchar(100) NOT NULL,
  `views` int NOT NULL DEFAULT '0',
  `uploader_email` varchar(100) NOT NULL,
  `uploaded_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`video_id`),
  KEY `uploader_email` (`uploader_email`),
  CONSTRAINT `video_ibfk_1` FOREIGN KEY (`uploader_email`) REFERENCES `users` (`email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video`
--

LOCK TABLES `video` WRITE;
/*!40000 ALTER TABLE `video` DISABLE KEYS */;
INSERT INTO `video` VALUES ('0srJwFoNSfkLXQDSZwjgbMm5rWNvCBwG','이강인 선수 초대석! #카타르월드컵',18,'user7@gmail.com','2022-12-10 07:10:05'),('9isggOYC9KfbfVg26O6vnzLLRojjLMag','아인슈타인의 친필 사인이 박힌 희귀 지폐의 가격',7,'user8@gmail.com','2022-12-10 07:04:34'),('A5OhsZKVMvkr07QIE2OTd2FrZQXm91lW','브루스 윌리스 최고의 반전 영화! - 식스센스(1999)',3,'user2@gmail.com','2022-12-10 06:35:50'),('Avf1bDgai7qL9FJjUY5gNJw9nfi0vlHZ','봐도봐도 웃긴 대박 사건ㅋㅋㅋ',8,'user4@gmail.com','2022-12-10 06:48:16'),('awRpmasPDO9OMQicLzOG5WtEHdYjd9oS','윤하 플레이리스트 1시간 (광고X)',6,'user3@gmail.com','2022-12-10 06:44:31'),('Bbo9qekAE4oZe3JkizoNFuc6PpkGgNCb','멘델스존 : 봄의 노래',2,'user1@gmail.com','2022-12-10 06:29:19'),('C99TbUX8y6nSpOt0Blhqlik9kzQ0AWoU','공학 기술의 집약체, 현수교',3,'user6@gmail.com','2022-12-10 06:57:21'),('CFAvmEiM39kuHdg0oaUJpBaLHCuHwDL5','\'억\' 소리 나는 그리스 금화!',3,'user8@gmail.com','2022-12-10 07:02:17'),('E22dSDIyXcoF5yCyg4EY2mAuyBJYpqbk','수능 1년도 안남은 고2 정시러의 브이로그',5,'user5@gmail.com','2022-12-10 06:53:06'),('GN1UvMAQp5jLg71mhPoOn1eCRDB3yLUo','Playlist 감성 힙합 2시간 (광고 없음)',7,'user3@gmail.com','2022-12-10 06:46:05'),('Gxis7HDTUKUeI2J0PWLYGru43viqzbo8','5 Habits of People with Good Painting Skills',0,'user9@gmail.com','2022-12-10 07:08:13'),('haqIE7tK1O66CAKoKj0ZcfCfuRAqqofW','초등학생들의 엉뚱한 시험 답안ㅋㅋㅋ',4,'user4@gmail.com','2022-12-10 06:49:50'),('hDl4vbcUDsRTYF2Wbmu6fteYV4X2tJk8','캐롤과 함께하는 연말 (Jazz music)',8,'user3@gmail.com','2022-12-10 06:45:13'),('Iltc83wQ1G3vZ1M9fOVyxQbuXGOYujfc','셔터아일랜드(2010) 리뷰 결말 포함',6,'user2@gmail.com','2022-12-10 06:33:37'),('IQuqFi5xNn8Zc7gP5uVkcBxRabtmPrAI','모의고사 시험장 백색소음 10시간',3,'user5@gmail.com','2022-12-10 06:54:00'),('J7UR63BwwH1LIN36LGbsjqKJwJx7WnyX','전 세계에 딱 10개만 존재하는 한정판 레고의 가격은?',2,'user8@gmail.com','2022-12-10 07:03:46'),('jf8qzdZCZukQ2EU12wNaH4oYG4iCz8EI','영유아도 이해하는 알고리즘의 원리',4,'user6@gmail.com','2022-12-10 06:58:22'),('jOlGyREOq55NJzYl2Xz6UNkgoyfvd4R3','모의고사 망한 날 친구들과의 엽떡 먹방',5,'user5@gmail.com','2022-12-10 06:55:04'),('JQcQR4AqGqAHW0fPlRlqv8ba4bl1oqw9','웃긴 밈 / 실수 모음 #1',4,'user4@gmail.com','2022-12-10 06:49:03'),('JzPbbUOUCRKtMCYQ4dPsW6dWz6oo5OnV','의료 수가란 무엇일까?',2,'user6@gmail.com','2022-12-10 06:56:11'),('LG1DFaqLnisjIlTIcP7uzZuktsMfNnIT','쇼팽 : 야상곡 2번',2,'user1@gmail.com','2022-12-10 06:31:00'),('lWAVtjvNig0VsIGL50cn9qM8C0Qz57Lf','반전 또 반전! - 유주얼서스펙트(1995)',4,'user2@gmail.com','2022-12-10 06:34:17'),('nBT2OvJ9Hp8EnhIaPELrHQe25MRREWKu','꿈에서 나갈 수 없다! - 인셉션(2010)',4,'user2@gmail.com','2022-12-10 06:39:29'),('nhy1AWUUceNFTvPfVCjEXNAd7lI02FPH','The Most Famous Painters Today',2,'user9@gmail.com','2022-12-10 07:07:32'),('nmC9NYdlWCY0jWqqp9tzvbpXgkF5i6Jg','비발디 : 4계 봄 1악장',2,'user1@gmail.com','2022-12-10 06:29:52'),('Q4AAe6p0Rk0HkW4ZZtJJDdkwBZ55iOK4','Top 10 Paintings of All Time',1,'user9@gmail.com','2022-12-10 07:06:33'),('sVfRfl0ksXYAFFNqE5xA17ymNxSfzyg3','코딩하면서 틀어 놓기 좋은 Jazz 3시간 플레이리스트',3,'user3@gmail.com','2022-12-10 06:42:24'),('sXHhC43n4TvH0ioRLrnunSUTgFDtqGpm','오늘도 평화로운 바보들의 하루',4,'user4@gmail.com','2022-12-10 06:50:28'),('u2AbGw39r3r1MzpT8zD5nZdGFnUqyUfk','당신을 종신형에 선고합니다. - 쇼생크 탈출(1994)',8,'user2@gmail.com','2022-12-10 06:38:05'),('V9RX4R5i0Urc3NreZsdIzHtL8OTZcweT','베토벤 : 로망스 2번',1,'user1@gmail.com','2022-12-10 06:32:00'),('xAQTAZJxP7sQpHtJlnDQnv8yQTzD9kj3','모차르트 : 아이네 크라이네',0,'user1@gmail.com','2022-12-10 06:30:09'),('YjfFuxxlQFwFZohMRIYAhKlXMp9FX95R','2022년 아이돌 노래모음 TOP 30 (가사 포함)',11,'user3@gmail.com','2022-12-10 06:43:07'),('Ztoao6AEhjM7eR4UZ3FQLNPUaVYmptJi','슈베르트 : 송어 4악장',0,'user1@gmail.com','2022-12-10 06:30:23');
/*!40000 ALTER TABLE `video` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-10 22:41:45
