-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: video_database
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `add_to_playlist`
--

DROP TABLE IF EXISTS `add_to_playlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `add_to_playlist` (
  `email` varchar(100) NOT NULL,
  `video_id` char(64) NOT NULL,
  `playlist_name` varchar(100) NOT NULL,
  `added_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`,`video_id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `add_to_playlist_ibfk_1` FOREIGN KEY (`email`) REFERENCES `users` (`email`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `add_to_playlist_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `video` (`video_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `add_to_playlist`
--

LOCK TABLES `add_to_playlist` WRITE;
/*!40000 ALTER TABLE `add_to_playlist` DISABLE KEYS */;
INSERT INTO `add_to_playlist` VALUES ('user1@gmail.com','0srJwFoNSfkLXQDSZwjgbMm5rWNvCBwG','다시보기','2022-12-10 07:11:46'),('user1@gmail.com','Q4AAe6p0Rk0HkW4ZZtJJDdkwBZ55iOK4','다시보기','2022-12-10 07:14:11'),('user2@gmail.com','sVfRfl0ksXYAFFNqE5xA17ymNxSfzyg3','내 음악','2022-12-10 07:26:44'),('user2@gmail.com','YjfFuxxlQFwFZohMRIYAhKlXMp9FX95R','내 음악','2022-12-10 07:26:18'),('user3@gmail.com','0srJwFoNSfkLXQDSZwjgbMm5rWNvCBwG','내 플레이리스트','2022-12-10 07:28:27'),('user3@gmail.com','J7UR63BwwH1LIN36LGbsjqKJwJx7WnyX','내 플레이리스트','2022-12-10 07:29:44'),('user3@gmail.com','JQcQR4AqGqAHW0fPlRlqv8ba4bl1oqw9','내 플레이리스트','2022-12-10 07:30:00'),('user3@gmail.com','lWAVtjvNig0VsIGL50cn9qM8C0Qz57Lf','내 플레이리스트','2022-12-10 07:30:13'),('user4@gmail.com','GN1UvMAQp5jLg71mhPoOn1eCRDB3yLUo','음악','2022-12-10 07:33:50'),('user4@gmail.com','hDl4vbcUDsRTYF2Wbmu6fteYV4X2tJk8','음악','2022-12-10 07:34:05'),('user4@gmail.com','Iltc83wQ1G3vZ1M9fOVyxQbuXGOYujfc','다시보기','2022-12-10 07:35:10'),('user4@gmail.com','LG1DFaqLnisjIlTIcP7uzZuktsMfNnIT','음악','2022-12-10 07:34:16'),('user4@gmail.com','lWAVtjvNig0VsIGL50cn9qM8C0Qz57Lf','다시보기','2022-12-10 07:34:35'),('user4@gmail.com','nBT2OvJ9Hp8EnhIaPELrHQe25MRREWKu','다시보기','2022-12-10 07:34:42'),('user4@gmail.com','u2AbGw39r3r1MzpT8zD5nZdGFnUqyUfk','다시보기','2022-12-10 07:34:56'),('user4@gmail.com','YjfFuxxlQFwFZohMRIYAhKlXMp9FX95R','음악','2022-12-10 07:35:46'),('user5@gmail.com','awRpmasPDO9OMQicLzOG5WtEHdYjd9oS','내 음악','2022-12-10 07:39:16'),('user5@gmail.com','Bbo9qekAE4oZe3JkizoNFuc6PpkGgNCb','내 음악','2022-12-10 07:39:06'),('user5@gmail.com','GN1UvMAQp5jLg71mhPoOn1eCRDB3yLUo','내 음악','2022-12-10 07:39:31'),('user5@gmail.com','hDl4vbcUDsRTYF2Wbmu6fteYV4X2tJk8','내 음악','2022-12-10 07:39:59'),('user5@gmail.com','IQuqFi5xNn8Zc7gP5uVkcBxRabtmPrAI','내 음악','2022-12-10 07:40:16'),('user5@gmail.com','LG1DFaqLnisjIlTIcP7uzZuktsMfNnIT','내 음악','2022-12-10 07:40:26'),('user5@gmail.com','YjfFuxxlQFwFZohMRIYAhKlXMp9FX95R','내 음악','2022-12-10 07:40:51'),('user7@gmail.com','GN1UvMAQp5jLg71mhPoOn1eCRDB3yLUo','내 플리','2022-12-10 07:49:52'),('user7@gmail.com','YjfFuxxlQFwFZohMRIYAhKlXMp9FX95R','내 플리','2022-12-10 07:49:40');
/*!40000 ALTER TABLE `add_to_playlist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-10 22:41:45
